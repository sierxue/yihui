---
title: Spring in Fall
date: '2007-10-05'
slug: spring-in-fall
---

Yesterday when I was wandering about in the campus, I found a somewhat amazing scene: there were many flowers blossoming alongside the alleys, which just reminded me of a feeling of the spring in this fall. Thus I took some photos for these beauties using my mobile phone:

![spring in fall 1](https://db.yihui.name/imgur/d1DXZ.jpg)

![spring in fall 2](https://db.yihui.name/imgur/AePr1.jpg)

![spring in fall 3](https://db.yihui.name/imgur/T2hkU.jpg)

![spring in fall 4](https://db.yihui.name/imgur/fx3Wa.jpg)

![spring in fall 5](https://db.yihui.name/imgur/GQxnY.jpg)

![spring in fall 6](https://db.yihui.name/imgur/qqnTu.jpg)

Hmmm... Interesting season :-)

