---
title: Learn formatR in Two Minutes
date: '2012-05-08'
slug: a-formatr-video
---

Anthony made a [video tutorial](http://www.screenr.com/Vap8) on how to use the [**formatR**](https://github.com/yihui/formatR/wiki) package, which I think is pretty cool:

<iframe src="http://www.screenr.com/embed/Vap8" width="600" height="365" frameborder="0"></iframe>

I wish I could speak English as fast as him...

