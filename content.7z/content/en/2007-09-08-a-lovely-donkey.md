---
title: A Lovely Donkey :-D
date: '2007-09-08'
slug: a-lovely-donkey
---

I see this donkey from [IconArchive](http://www.iconarchive.com/category/animals/animals-icons-by-turbomilk.html) when I was searching for an icon for my web pages:

![A Lovely Donkey](http://icons.iconarchive.com/icons/turbomilk/animals/256/donkey-icon.png)

It's lovely, isn't it?

