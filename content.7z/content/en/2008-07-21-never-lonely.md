---
title: Never Lonely
date: '2008-07-21'
slug: never-lonely
---

A beautiful video:

<embed src="http://www.tudou.com/v/ZpUOvGpCxoA/&resourceId=0_05_02_99/v.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" wmode="opaque" width="480" height="400"></embed>

