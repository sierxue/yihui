---
title: Funny Mark Twain
date: '2007-12-03'
slug: funny-mark-twain
---

Money is always important! :-D

> The holy passion of Friendship is of so sweet and steady and loyal and enduring a nature that it will last through a whole lifetime, if not asked to lend money.
>
> --- Mark Twain
