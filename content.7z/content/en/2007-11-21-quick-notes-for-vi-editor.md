---
title: Quick Notes for VI Editor
date: '2007-11-21'
slug: quick-notes-for-vi-editor
---

- Press `ESC` to enter _command mode_;
- `a/i` to enter _insert_ mode;
- `dd` to delete a line;
- `x` to delete the character under the cursor;
- `:q` quit; `:q!` quit without saving; `:wq` write the buffer and quit.

