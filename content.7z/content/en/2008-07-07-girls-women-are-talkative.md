---
title: Girls / Women are Talkative?
date: '2008-07-07'
slug: girls-women-are-talkative
---

I'm sorry but these words are not from my mouth:

> I haven't spoken to my wife in years. I didn't want to interrupt her. (by Rodney Dangerfield)

And I happened to find a funny illustration for this quotation:

![I haven't spoken to my wife in years. I didn't want to interrupt her.](http://farm4.static.flickr.com/3112/2643743145_0b50e89f9c.jpg)

