---
title: R is an Epic Fail?
date: '2010-04-15'
slug: r-is-an-epic-fail
---

I came across this blog post just now: [The  Next Big Thing](http://www.thejuliagroup.com/blog/?p=433), and of course these words caught my attention:

> [...] However, for me personally and for most users, both individual and organizational, the much greater cost of software is the time it takes to install it, maintain it, learn it and document it. On that, R is an epic fail.

I don't really understand how (much more?) difficult will it be to install and maintain R. Usually it takes about one minute to install it from the binary (and SAS? SPSS? buy it, find a technician, install it, maintain according to different licenses - single PC or server or other types, continue to pay only tens of thousand dollars next year, ...). For learning, it depends. I don't think it is too difficult for people who know well about statistics, and for the rest of people, do they really feel safe to do something they do not understand? For the documentation, some people prefer simple ones and some prefer handbooks (of SAS-style).

In all, I cannot see why R is an epic fail for the above reasons...

What? Data visualization? ...

The R community must have been tired of comparing SAS with R. Please don't tell [Prof Frank Harrell](/en/2010/04/rules-of-thumb-to-meet-r-gurus-in-the-help-list/) about this post...
