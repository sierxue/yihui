---
title: Quincunx (Galton box, Bean machine) in R
date: '2008-10-20'
slug: quincunx-in-r
---

Yesterday I wrote some R code to simulate the quincunx, and I wrote an R function `quincunx()` in the [animation](http://cran.r-project.org/package=animation) package. Here is a [video](http://vimeo.com/2013914):

<iframe src="http://player.vimeo.com/video/2013914?title=0&amp;byline=0&amp;portrait=0" width="400" height="333" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>

