---
title: Enhanced tidy.source() (Preserve Some Comments)
date: '2009-03-31'
slug: enhanced-tidy-source
---

After a few hours' work, I modified the function `tidy.source()` in the [formatR](http://cran.r-project.org/package=formatR) package so that it can preserve _complete_ comment lines. See `formatR::tidy.source` and <https://github.com/yihui/formatR/wiki> for details.

