---
title: Listening is A Better Way to Improve Pronunciation
date: '2007-12-27'
slug: listening-is-a-better-way-to-improve-pronunciation
---

I used to try hard to remember the pronunciations of English words by looking up the phonetic symbols over and over again in a dictionary, which was indeed quite inefficient. This evening I read a post about learning English, and one of the viewpoints of the author was that one should remember the pronunciations via listening instead of phonetic symbols. I believed he was right after I corrected one of the confusing pronunciations of one word "sp**e**cify" (`[e]` or  for the "e") from the VOA radio programs.

