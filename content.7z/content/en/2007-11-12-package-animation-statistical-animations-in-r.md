---
title: 'Package animation: Statistical Animations in R'
date: '2007-11-12'
slug: package-animation-statistical-animations-in-r
---

Yesterday I have submitted a package called "animation" to CRAN. You may get it from CRAN (<http://cran.r-project.org/package=animation>).

This package aims at illustrating various statistical methods and data analyses in a form of _animation_.
