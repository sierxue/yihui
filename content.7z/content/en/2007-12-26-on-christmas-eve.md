---
title: On Christmas Eve...
date: '2007-12-26'
slug: on-christmas-eve
---

On the Christmas Eve, there was a man dressed as "Santa Claus" in the street, with a bag in his hands as usual... So everybody just gazed at that big bag, thinking about how many presents were there...

Guess what?

This "Santa" opened his bag and asked the passers-by, "Ladies and gentlemen, would you please give me some money?" -_-//

