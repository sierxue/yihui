---
title: Statistical Animations Using R - A Talk at useR! 2008
date: '2008-08-14'
slug: statistical-animations-using-r-a-talk-at-user-2008
---

As a few participants told me that they were interested in my animations and hoped to get a copy of my presentation, I have uploaded the [slides](https://github.com/downloads/yihui/yihui.github.com/animation-useR-2008-Yihui-Xie.ppt) for you to download.

Don't forget to visit <http://animation.yihui.name> to find more animations. To know more about the package, please read the [documentation page](http://animation.yihui.name/animation:start). Feedbacks & comments are especially welcome!

