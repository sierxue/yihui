---
title: Handbook of Computational Statistics
date: '2008-05-13'
slug: handbook-of-computational-statistics
---

I just found this page for the book [Handbook of Computational Statistics](http://www.springer.com/statistics/computational/book/978-3-540-40464-4) by chance:

<http://fedc.wiwi.hu-berlin.de/xplore/ebooks/html/csa/>

Thanks for the update, Felix.

