---
title: 'AniWiki: Animations in Statistics'
date: '2008-05-31'
slug: aniwiki-animations-in-statistics
---

I have finished the TOEFL test today and ultimately I can spend enough time on the animation wiki now:

<http://animation.yihui.name>

This idea came to my mind the other day; maybe it is quite natural, because what I plan to do is a gallery instead of a limited number of animations. Thus I must choose a way that can interact with other people. The most ideal case, in my mind, would just be a wiki, in which there can be a large amount of different ideas and feedbacks, meanwhile, as I said in the [message page](http://animation.yihui.name/wiki:message), "Many hands make light work". I really wish people who are interested in animations can create this wiki together with me.

In the next few days, I'll have to rewrite the JavaScript code in HTML animation pages so that it can be more flexible to be used elsewhere. Besides, the animation functions to create HTML pages will also be revised.

By the way, the old website http://R.yihui.name is to be abandoned as there is too much inconvenience to maintain!

