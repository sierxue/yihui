---
title: At the Beginning of the Year 2008
date: '2008-01-01'
slug: at-the-beginning-of-the-year-2008
---

This is a special moment.

Time flies like a rocket... I must make full preparations for the new year because there might be great changes to my life one year later. Now my aim is to find an appropriate direction for me to study abroad. Recently I felt the directions for the applications of statistics are much easier than theories -- I really dislike those _pure_ mathematical theories (although I know the importance)...

