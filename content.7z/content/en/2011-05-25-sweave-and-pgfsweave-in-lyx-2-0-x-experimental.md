---
title: Sweave and pgfSweave in LyX 2.0.x (experimental)
date: '2011-05-25'
slug: sweave-and-pgfsweave-in-lyx-2-0-x-experimental
---

Please ignore this post completely, because Sweave support has become mature in LyX since 2.0.2, and I no longer plan to add the pgfSweave module in LyX. For pgfSweave users, you may consider the new [knitr module](/knitr/demo/lyx/) (available since 2.0.3) which uses the R package [knitr](http://cran.r-project.org/package=knitr).

![knitr module in LyX 2.0.3](https://db.yihui.name/imgur/jEKSh.png)

