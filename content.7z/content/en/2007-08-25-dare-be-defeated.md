---
title: Dare be defeated?
date: '2007-08-25'
slug: dare-be-defeated
---

It sounds easy to admit that you've lost a war, whereas when you are in a war, everything just changes.

> The quickest way of ending a war is to lose it. (George Orwell)

