---
title: A Cartoonizer Web Site
date: '2008-01-01'
slug: a-cartoonizer-web-site
---

Here is a web site which can "cartoonize" your photos: <http://www.befunky.com>

I made a new year card with the help of this site as well as `Fireworks` and [R](http://www.r-project.org). As I have more than 1600 people in my contact list, Gmail forbade me from sending emails after I sent my new year's greeting to about 900 people... -_-//

