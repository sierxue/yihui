---
title: My Talk on Animations at useR! 2010 (NIST, Gaithersburg)
date: '2010-07-21'
slug: my-talk-on-animations-at-user-2010
---

As every useR knows, the useR! 2010 conference is being held at NIST in Gaithersburg these days. I have just finished my talk on the R package **animation** this afternoon. Here are [my slides](https://github.com/downloads/yihui/yihui.github.com/animation-useR2010-Yihui-Xie.pdf) and [R code](https://gist.github.com/2166508) for those who are interested.

Have fun, even if you are a PhD!

![Lilac Chaser](https://db.yihui.name/imgur/eDSiw.gif)

