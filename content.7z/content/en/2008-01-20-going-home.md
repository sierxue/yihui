---
title: Going Home
date: '2008-01-20'
slug: going-home
---

I'll take the train and go home tomorrow, which indicates my absence from the internet for about one month. During this month, I'll try to finish writing my book on statistical graphics with R as well as some other papers at home.

Adieu...

