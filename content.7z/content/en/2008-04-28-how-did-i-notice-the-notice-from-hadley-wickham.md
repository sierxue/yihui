---
title: How Did I Notice the Notice from Hadley Wickham
date: '2008-04-28'
slug: how-did-i-notice-the-notice-from-hadley-wickham
---

Who is Hadley Wickham? Actually I was not quite sure until I received an email from his major professor [Di Cook](http://www.public.iastate.edu/~dicook) just now... But I have already noticed this interesting guy a couple of days ago, or more definitely speaking, I just noticed his notice about my website.

![The notice about a notice...](https://db.yihui.name/imgur/d8R3F.jpg)

The other day when I was reading the statistics about my homepage, I noticed that there was a special link (officially called "HTTP referer") in the list of referring sites: <http://crantastic.org/packages/1290>. This domain name is really fantastic! Following this site, I just found his homepage here: <http://had.co.nz/>

I wonder whether Hadley will notice this notice about my notice of his notice of my website, anyway, guys who have noticed my notice about his notice of me are all noticed now. Also, keep notice that your notice of this notice is noticeably not worth noticing, and may be noticed by those who noticed you noticing this notice.
