---
title: "Publications"
slug: "en/publication"
---

Please see my [vitae](../vitae/).
