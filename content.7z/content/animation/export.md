---
title: Export animations
date: '2017-03-29'
slug: export
---

If you want to export animations from R, you may use one of these methods:

- `saveHTML()`
- `saveGIF()`
- `saveVideo()`
- `saveLatex()`
- `saveSWF()`
