---
title: Examples
subtitle: A gallery of animations for statistics
date: 2017-03-29
layout: example
show_title: true
list_pages: true
order_by: title
---

Below is a list of examples (under construction <i class="fa fa-spinner fa-pulse fa-fw"></i>) for functions in the **animation** package. To see or contribute other examples, please go to the [resources](../resources) page.
