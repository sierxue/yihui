---
title: Examples
subtitle: Source and output of demos
date: '2017-02-03'
layout: example
list_pages: true
---

Note there is a larger collection of examples in the [knitr-examples](https://github.com/yihui/knitr-examples) repository on Github. This page is more for the documentation purpose. You can take a look at the [collection of knitr applications](../demo/showcase) by other users as well.
