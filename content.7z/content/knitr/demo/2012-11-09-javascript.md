---
title: JavaScript
subtitle: Combine R and JS applications like D3
date: '2012-11-09'
slug: javascript
---

Due to the option `results='asis'`, we can write anything to the output, including JavaScript. Here are some examples:

- [Contour Plots with D3 and R](http://vis.supstat.com/2012/11/contour-plots-with-d3-and-r/) ([source](https://github.com/supstat/vistat/blob/gh-pages/_source/2012-11-07-contour-plots-with-d3-and-r.Rmd))
