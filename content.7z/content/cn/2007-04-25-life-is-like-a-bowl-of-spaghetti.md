---
title: Life is Like a Bowl of Spaghetti
date: '2007-04-26T00:27:00+08:00'
slug: life-is-like-a-bowl-of-spaghetti
---

A man from China Asset Management Co.,Ltd (HuaXia JiJin) wanted to cooperate with me in the analysis of their data cubes. I'm quite interested.  

A doctor from the Institute of Botany, Chinese Academy of Science wanted to cooperate with me in statistical analysis and the usage of S-Plus in their English papers. I'm also interested in it.  

Perhaps I should go to People's Bank of China again this Friday, and I have to add some content to my slides.

An outline on the training course of EViews needs to be prepared these days. And it's the same with R.  

I must find some applications of Java, and I wonder whether there're special "libraries" or "packages" for statistics.

I'd better publish the first volume of the electronic journal of [COS](http://www.cos.name) before May 7th.

And, I think I have another two reports to write.
