---
title: 'Mobile Phone v.s. Mouse: A Funny Habit'
date: '2007-05-16T21:58:39+08:00'
slug: mobile-phone-v-s-mouse-a-funny-habit
---

When I put my mobile phone on my right side in front of the LCD, usually I'll unconsciously take it as my mouse...

---

Two irrelevant quotations:  

> "If only we'd stop trying to be happy we could have a pretty good time."
> 
> --- Edith Wharton  

<!-- -->

> "Ask yourself whether you are happy and you cease to be so."
> 
> --- John Stuart Mill
