---
title: English Classes for Postgraduates
date: '2007-04-26T22:14:13+08:00'
slug: english-classes-for-postgraduates
---

![English courses](https://db.yihui.name/space/english.gif)

I insist that such classes should be canceled, because what we need is no longer the knowledge from special English classes. To some degree, these classes are listed in the schedule of our teaching programs just in case that some teachers should have nothing to do and some students should totally forget English.

Many students in the major of statistics don't know words like "pilot survey", "positive definite", "imputation", "interpolation", "multicollinearity" and "eigenvalue", etc, so I wonder what's the use of English classes. Reading English textbooks and papers in our major will be much better -- usually we badly lack this kind of practice.  

This evening Yu WU asked me how to describe the place of an object below another, and I told him the word "beneath", but it seemed that he didn't know how to spell it. It's strange.  

