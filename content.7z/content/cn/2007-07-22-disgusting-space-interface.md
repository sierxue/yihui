---
title: Disgusting Space Interface
date: '2007-07-22T17:52:13+08:00'
slug: disgusting-space-interface
---

M$ never understands art design? Why the new version is so disgusting and inconvenient...
