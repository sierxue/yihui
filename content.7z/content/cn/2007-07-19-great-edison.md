---
title: Great Edison -___-||
date: '2007-07-19T19:08:39+08:00'
slug: great-edison
---

> "Do you realize if it weren't for Edison we'd be watching TV by candlelight?"
> 
> --- Al Boliska
