---
title: 正式搬家到yihui.blog.com.cn了
date: '2006-02-15'
slug: yihui-blog-com-cn
---

感谢所有过去关注过我的Blog的朋友们，在这边我就不发新文章了，但如果还有评论，我仍会回来回复。欢迎造访新家：<http://yihui.blog.com.cn>，多多提意见！：）
