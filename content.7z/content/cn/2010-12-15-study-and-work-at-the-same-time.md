---
title: 工作学习两不误
date: '2010-12-15'
slug: study-and-work-at-the-same-time
---

有欢乐的客官发来欢乐的图片一幅，本小子看了也表示很欢乐，供来往行人参观：

![工作学习两不误](https://db.yihui.name/imgur/vH2qLRh.jpg)

正溜达着，又看见另一幅很欢快的毕业照：

![欢快毕业照](http://funnyinchina.com/wp-content/uploads/2010/05/teachers-team-photo.jpg)
