---
title: R社区实现了共产主义……
date: '2009-02-18'
slug: communism-in-r-community
---

话说今日R-help邮件列表中，[俺给人回答了一个问题](https://stat.ethz.ch/pipermail/r-help/2009-February/188789.html)，被Roger Koenker看到了，老爷子回复了一句：

> Why I love R [Number 6]:

> Chinese extend a helping hand to Russians who happen to be in Brazil about a package written in Germany. Trotsky would be proud -- and amazed!

我又加了一句：

> "Chinese extend a helping hand to Russians who happen to be in Brazil about a package written in Germany," which gladdened an American. Trotsky would be even more proud -- and amazed!! :-)

看来，R社区已经实现了共产主义。
