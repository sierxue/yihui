---
title: 送给Felix的一万天“生日”小礼
date: '2008-10-27'
slug: birthday-present-to-felix-andrews
---

话说上周请[Felix](http://nfrac.org/felix/cv.html)过来作报告，结果最后只有三四个人来听。Felix生于1981年6月6日，报告那天是10月22日，用R计算一下时间差，刚好是一万天，所以他第一张幻灯片就说“我活了一万天了”，有意思。晚上吃饭，他说如果过生日的话得要一万根蜡烛，后来我回到电脑前想，何不把蜡烛藏在数据中让他用他自己的R包去探索呢？于是就有了下面的老套故事：

<iframe src="https://player.vimeo.com/video/2077814" width="500" height="500" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> <p><a href="https://vimeo.com/2077814">&quot;Candle&quot; in the points</a> from <a href="https://vimeo.com/yihui">Yihui Xie</a> on <a href="https://vimeo.com">Vimeo</a>.</p>

这是他用playwith包给我的答案：

![数据中隐藏的“蜡烛”](https://db.yihui.name/imgur/tvDxB4g.png)
