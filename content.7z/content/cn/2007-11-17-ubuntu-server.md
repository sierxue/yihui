---
title: Ubuntu Server：两眼一抹黑
date: '2007-11-17'
slug: ubuntu-server
---

就服务器的操作系统选择来说，Windows Server根本就不在考虑之列。今天拿一台机器试装了Ubuntun 7.10的Server系统，那只能用两眼一摸黑来形容：对着Command Line Interface（没有GUI，服务器也没有必要用GUI），完全找不着北。装了LAMP，基本的静态网页服务应该是能跑了。而对于昏天黑地的MySQL命令、Apache设置和PHP设置，还在继续眩晕中。

刚刚才知道怎样看自己的IP地址：ifconfig命令。ft。

作为Linux世界中的幼儿园级小盆友，只能继续自学了……

