---
title: 递归
date: '2015-01-10'
slug: recursion
---

谷歌搜索关键词X的时候可能会自动纠错，问你本来想搜的是Y吧？而搜recursion（递归）的时候会自动卖萌问，你本来想搜的是*recursion*吧？

[这里](http://www.newsmth.net/bbscon.php?bid=63&id=3393726)也有个递归：

> 医生要给我打麻醉针，我怕针扎着疼，医生说：“既然怕疼，那我先给你打麻醉针。”

我琢磨着这对话循环往复进行下去到一定程度，医生最后大概会说：

> Error: evaluation nested too deeply: infinite recursion / options(expressions=)?

