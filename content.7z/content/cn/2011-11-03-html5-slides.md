---
title: HTML5幻灯片
date: '2011-11-03'
slug: html5-slides
---

这大概是我在WordPress下写的最后一篇日志，我要奔向静态网站了。昨天[在系里](http://www.stat.iastate.edu/seminars/seminar.html?id=649)做了个小报告，漫谈一下这几年开发R包的一些故事，基本上是鬼扯。这次的报告摘要是目前写得最成功的一个，因为一点都不严肃，通知发出去之后好几个人遇到我都号称“贼喜欢这摘要”，让我忍不住小得意了一番。由于早已厌倦学术报告上清一色的Beamer片子，我后来投奔古老的Foiltex（基本上就是白纸），这次[尝试了一下HTML5](//slides.yihui.name/2011-r-dev-lessons.html)，片子做出来我自己都觉得增加了不少讲的动力，因为风格完全自由了，愿意放图就放图，愿意用什么字体就用什么字体，简言之，要多华丽有多华丽。这片子有多难做呢？答案是会打字基本上就够了。我用的是keydown，Ruby Gem一枚，片子的[源代码](https://raw.github.com/yihui/yihui.github.com/master/slides/2011-r-dev-lessons.md)极其简单。

珍爱生命，远离`\includegraphics{}`。

又及：珍爱生命，远离IE。
