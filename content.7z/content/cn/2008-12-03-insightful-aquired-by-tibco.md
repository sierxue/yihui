---
title: Insightful公司被TIBCO收购了
date: '2008-12-03'
slug: insightful-aquired-by-tibco
---

刚刚得知，S-Plus那个公司被收购了，莫非也是金融危机的影响？……

不知此后S-Plus的路会怎样（仅得知软件价钱会涨），拭目以待。
