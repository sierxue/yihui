---
title: Interesting Man; Everything Dies?
date: '2007-05-10T23:56:30+08:00'
slug: interesting-man-everything-dies
---

Here are two quotations:

"Give a man a fish and he will eat for a day. Teach a man to fish and he will eat for a lifetime. Teach a man to create an artificial shortage of fish and he will eat steak."

Jay Leno

"I have a rock garden. Last week three of them died."

Richard Diran

(Perhaps somebody doesn't know what's "rock garden".)
