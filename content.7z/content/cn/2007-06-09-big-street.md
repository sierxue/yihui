---
title: '"Big" Street'
date: '2007-06-09T19:26:58+08:00'
slug: big-street
---

Just now, a doctor was writing the address of our school, and beside her another doctor murmured "... No. 59, Zhongguancun Big Street...", which was written by the first doctor.

After I thought for a while, I eventually knew what she meant. That is:

> "Zhongguancun Da Jie..." Orz & `*__________*////`

By the way, I've read eight compositions today. And... finally got the degree of "permanent head damage" (PHD)... What a happy "numb"!   
