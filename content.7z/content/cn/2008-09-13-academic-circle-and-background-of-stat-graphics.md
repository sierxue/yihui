---
title: 话说圈子的大小以及统计图形的背景
date: '2008-09-13'
slug: academic-circle-and-background-of-stat-graphics
---

这是两个主题。先说第一个：最近[Alfred Inselberg](http://www.math.tau.ac.il/~aiisreal/)老爷子去韩国了，给我写了一封邮件，说要给我介绍另一个"Joke Man"，他叫[Moon Yul HUH](http://stat.skku.ac.kr/myhuh/)。我当时没在意这个名字，上网搜了搜，SKKU的统计系网站打不开，什么都看不到，而今天突然发现这位教授10月份要来我们学院开一场讲座，心中大惊，数据可视化的圈子真小。等他来了我们可以来一个Joke擂台赛。

第二个：浏览网页看着看着，看到[Martin Theus](http://rosuda.org/%7Etheus/)那旮旯去了，突然发现原来[这个Blog](http://statisticalgraphics.blog.com/)是他写的！以前有眼不识泰山，今天又好好看了一遍，看着看着又链接到另一个[R图形网站](http://zoonek2.free.fr/UNIX/48_R/04.html)上去了，往下拖着看的时候突然又想到我在书中提到的统计图形的设计要适应问题的背景，比如全球变暖的图应该用火焰般的面积图。然后我就操起键盘设计了这样一幅关于婚姻幸福的饼图（[数据来源](http://news.sohu.com/20060901/n245103639.shtml)）：

![婚姻幸福比例](https://db.yihui.name/imgur/DNtTSZT.jpg)

