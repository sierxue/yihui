---
title: Endless Reading of Books, Endless Killing of Pigs
date: '2007-05-22T21:39:18+08:00'
slug: endless-reading-of-books-endless-killing-of-pigs
---

Teacher MZ Tian is good at telling folksays...
