---
title: Notes on "The Effective Executive" (2)
date: '2007-05-02T23:58:36+08:00'
slug: notes-on-the-effective-executive-2
---

Some principles for the precedence of doing things:

1. Put your eyes on the future instead of the past. ("Get rid of the stale and bring forth the fresh." Don't waste time on past things which can no longer generate fruits. And "future" usually means new environments.)
2. Opportunities are more important than difficulties.
3. Choose your own direction, and don't follow others like sheep.
4. Set your aim high, make novelties, and don't merely pay attention to safety and convenience.  
