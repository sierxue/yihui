---
title: Hadley批A First Course in Statistical Programming with R
date: '2009-03-26'
slug: hadley-reviews-a-first-course-in-statistical-programming-with-r
---

话说去年底Hadley在JSS上把A First Course in Statistical Programming with R这本书[批了一顿](http://www.jstatsoft.org/v28/b03/paper)。建议大家看看书评，我感觉他和作者的私人关系还是很好的，放在国内这种事情大约是不会出现的，不过这小子毫不客气，书写得不好就是不好。
