---
title: 八个月论文初审
date: '2009-01-05'
slug: paper-review-in-8-months
---

话说四月份给JSS投稿一篇（关于animation），等啊等啊，一直等到今天才收到编辑的回复，历时八个月……好在编辑大人基本上还是持肯定意见的，进一步指示是"revise and resubmit"。

翻了一下邮箱，发现投给R News的论文从投稿到被接收，也花了五个多月。再看国内期刊，据我过去投稿的经验来看，一般两三个月也就差不多了。

顺便提一下最近写PS，分别发给John Maindonald、Di Cook、Moon Yul HUH，各位大人洋洋洒洒回信之长，让我读信读得比写PS还费力，尤其是John大爷，让我进一步明白了Di当时说的"attention to details"是一种什么样的品格，还有Moon大人，我本没有请求他的意见，结果这位大人不请自写了。看样子还是不要轻易攻击数学理论，低调，低调。
