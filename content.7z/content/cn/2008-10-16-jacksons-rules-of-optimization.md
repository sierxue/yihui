---
title: Jackson's Rules of Optimization
date: '2008-10-16'
slug: jacksons-rules-of-optimization
---

今天Ripley在回答一个问题时提到"Jackson's Rules of Optimization"，这两条规则是：


> 1) Don't do it.
2) (For experts only) Don't do it yet.
