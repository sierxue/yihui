---
title: 点一下右键就知道你是程序员
date: '2008-07-07'
slug: programmer-and-svn
---

话说老谢今天下午去新浪帮忙解决问题，一伙人坐在会议室说着话，老谢用眼角瞥见一人点了一下右键，弹出如下菜单，心中便知，这位铁定是程序员了：

![](https://db.yihui.name/imgur/ZFqtK.png)

各位看官想必用SVN的并不多，所以对此菜单可能也没感觉。这老谢其实也是前两天刚刚花了几个小时看了一下SVN，啥都不懂，只知道改代码，然后Commit，服务器上的文件就更新了，而且新旧版本可以很方便地比较差异。这都是拜[R-Forge](http://r-forge.r-project.org/)所赐，前段时间我在R-Forge上新开了一个项目，有兴趣的可以[去瞅瞅](http://r-forge.r-project.org/projects/animation/)。
