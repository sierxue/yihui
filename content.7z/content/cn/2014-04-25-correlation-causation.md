---
title: 相关关系不等于因果关系
date: '2014-04-25'
slug: correlation-causation
---

我们都知道相关关系不能代表因果关系，这条狗虽然不懂这一点，但不懂有不懂的好处：反正主人一起身我就要去散步，管你什么相关关系因果关系。

![](https://db.yihui.name/imgur/uiCx9nX.png)
