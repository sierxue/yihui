---
title: Poor Google Pages...
date: '2007-06-05T16:12:54+08:00'
slug: poor-google-pages
---

Really disgusting! I don't know the real reason of "googlepages" being blocked, but surely something in "Google Pages" has violated something, again.

Now [my resume pages](http://xieyihui.googlepages.com/) has to be accessed through a certain proxy, e.g. <http://www.proxyhub.co.uk> (this is a good proxy which I'd like to recommend; so you can visit my resume in China [through this link](http://www.proxyhub.co.uk/index.php?q=kvrlvuhv.tbbtyrcntrf.pbz&hl=0011110001))  

![](http://static.flickr.com/38/123101128_930ac6f68f.jpg)

Actually this kind of blocking has no influence on my own visiting those blocked websites because I use [Firefox](https://addons.mozilla.org/en-US/firefox/) and an according add-on named "[gladder](https://addons.mozilla.org/en-US/firefox/addon/2864)", thus I can conveniently look up information in web pages such as [Wikipedia](http://www.wikipedia.org), etc. But for most novices not knowing proxy, a blocked site can never be accessed again.

---

An irrelevant quotation:

> "We are what we pretend to be, so we must be careful what we pretend to be."
> 
> --- Kurt Vonnegut
