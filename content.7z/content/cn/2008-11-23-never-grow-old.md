---
title: Never Grow Old
date: '2008-11-23'
slug: never-grow-old
---

这首歌还挺好听的，小子我今晚就听着这首歌写下了“统计之都”的[关于页面](http://cos.name/about/)。顺便发布一下通知，统计之都自今日起全面转型（访问[新的统计之都网站](http://cos.name)），我在两年多前的“博客+论坛”结构终于出现在人世间了，另外还加上了维基。从现在起，要真正开始广邀天下统计英雄共同建设这座都城了。

	I had a dream
	Strange it may seems
	It was my perfect day

	Open my eyes
	I realize
	This is my perfect day

	Hope you never grow old
	Hope you never grow old
	Hope you never grow old
	Hope you never grow old

	Do-do-do-do

	Birds in the sky
	They look so high
	This is my perfect day

	I feel the breeze
	I feel it is
	It is my perfect day

	Hope you never grow old
	Hope you never grow old
	Hope you never grow old
	Hope you never grow old

	Forever young
	I hope you stay
	Forever young
	Do-do-do-do
