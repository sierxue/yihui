---
title: Celebration to An Ending of A Course
date: '2007-05-24T23:58:57+08:00'
slug: celebration-to-an-ending-of-a-course
---

The course "Qualitative Data Analysis" came to the end at last today. I'm so happy.

Mr Fei P praised our website "[the Capital of Statistics](http://www.cos.name)" in the class (because he heard about this site from some students in Fudan University when he paid a visit there) and changed his viewpoints about me (in the last class he seemed to be very unhappy for my opinions).

Yet, there are still too many "pigs" to kill.  

