---
title: Inverse Empirical Cumulative Distribution
date: '2008-09-26'
slug: inverse-empirical-cumulative-distribution
---

这个好玩。今天有一个JP摩根的人在R-help里问了个问题，题目很吓人，说R里面有没有可以求Inverse经验分布的函数。我初一看吓坏了，这是啥函数啊，赶紧拿笔在纸上画了一下经验分布函数，然后把它Inverse过来，最后想，这不就是分位数函数么！

这不就是分位数函数么！这不就是分位数函数么！这不就是分位数函数么！……

另：[Peter Dalgaard](http://biostat.ku.dk/~pd)比较严谨，告诉人家要用quantile()中的第7类求法。我颠颠儿去看了一下帮助，不看不知道，一看吓一跳，分位数的求法一共有9种！分位数的求法一共有9种！ 分位数的求法一共有9种！……
