---
title: The Rabbit Fishing Again
date: '2007-06-12T21:57:37+08:00'
slug: the-rabbit-fishing-again
---

Mr. Rabbit went fishing again today. First he used some leaves from a tree as the bait but got no fish. Then used bread and got no fish either. Then earthworms, and none again.

Eventually he was rather angry. And... He threw 100$ into the river... shouting:

> "Damn you! What on earth do you want to eat?! Just go shopping for yourself!"

This story tells us that... freedom is important `+____+///`
