---
title: Assignments, Lectures, Reports and Training
date: '2007-04-19T20:39:53+08:00'
slug: assignments-lectures-reports-and-training
---

I didn't imagine that I could be driven madly by these affairs. Today I spent two hours in the morning and two in the evening on one of the class assignments and eventually finished it. Last week I prepared a report for the class of marketing and this week it seems that I should prepare a report on the introduction to Java (next Monday afternoon?), a lecture note on structural equation modeling (next Monday morning), a report on support vector machines (next Tuesday morning), a training course for People's Bank of China on Stata (tomorrow afternoon) and a lecture note on statistical programming and analysis with R (in May).

Yep, for me, life is a box of chocolates -- the chocolates are not for me.  
