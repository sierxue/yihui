---
title: 寻找灵感：StatSci
date: '2008-06-11'
slug: inspiration-from-statsci
---

这是一个统计资源的汇总网站：<http://www.statsci.org>，可以从中“窃取”别人的主意，转化为R代码（据我观察，过去的动画大部分都是基于Java Applet做的），要充分利用R在计算上的优势，相比之下，Java写统计代码太痛苦了。

上回[Hadley](http://had.co.nz/)告诉我另外两个网站：

- <http://www.cs.nyu.edu/algvis/html/abstract.html>
- <http://www.cs.ubc.ca/~harrison/Java/sorting-demo.html?donttaseme>

其中那个排序的demo我以前看过，的确很经典。这些都可以作为思维的源泉。
