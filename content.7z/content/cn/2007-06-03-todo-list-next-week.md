---
title: TODO List Next Week
date: '2007-06-03T23:55:44+08:00'
slug: todo-list-next-week
---

1. Today Dr KUANG told me that they had bought the website of 8sta (www.8sta.com), and I was quite surprised. I knew that web was to be sold, but I didn't expect it was at last bought by them. Thus I have to make a good plan for managing two websites (COS & 8sta) because I'm interested in this site too. However, the biggest headache will be the notions of these two websites. As the administrator, I must be very clear about the roles which they play respectively. This is what I'm to consider in the near future.
2. I'm going to make several modifications to the web pages of "BIstone Inc." after a glance at some pages: there're still much room to improve. Total time for this task seems to be rather limited.
3. A research project on statistical quality control co-operated with China National Research Institute of Food and Fermentation Industries, National Standardization Centre of Food & Fermentation Industry, P.R.C.; I have great interest in this project because of both the personality of my co-worker (I like his passion) and the usage of R again.  
