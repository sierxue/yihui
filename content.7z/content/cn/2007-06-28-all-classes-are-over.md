---
title: All Classes Are Over
date: '2007-06-28T22:46:41+08:00'
slug: all-classes-are-over
---

But there's still too much work to do :-(

---

By the way, yesterday I registered a domain name for myself: <http://yihui.name>. I plan to build a genuine personal website during this summer holiday and drop all my other websites such as blogs or spaces. I never have a sense of safety (or satisfaction) when using services which do not really belong to myself. Now you may visit `http://blog.yihui.name` for this MSN space, but the [homepage](http://www.yihui.name) is not available currently.  

