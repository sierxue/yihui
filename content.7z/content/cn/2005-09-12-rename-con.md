---
title: 文件夹不可以重命名为con
date: '2005-09-12'
slug: rename-con
---

真是怪事！Windows竟然还有这么一点限制，真是奇怪啊。把文件夹重命名为con之后立刻就又会变成原来的文件夹名……
