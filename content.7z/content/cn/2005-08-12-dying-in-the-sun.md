---
title: Dying in the Sun
date: '2005-08-12'
slug: dying-in-the-sun
---

A song that makes you feel the remoteness and vacancy...

---

> Do you remember  
> The things we used to say?  
> I feel so nervous  
> When I think of yesterday
> 
> How could I let things  
> Get to me so bad?  
> How did I let things get to me?
> 
> Like dying in the sun  
> Like dying in the sun  
> Like dying in the sun  
> Like dying...  
> Like dying in the sun  
> Like dying in the sun  
> Like dying in the sun  
> Like dying...
> 
> Will you hold on to me  
> I am feeling frail  
> Will you hold on to me  
> We will never fail
> 
> I wanted to be so perfect you see  
> I wanted to be so perfect
> 
> Like dying in the sun  
> Like dying in the sun  
> Like dying in the sun  
> Like dying...  
> Like dying in the sun  
> Like dying in the sun  
> Like dying in the sun  
> Like dying...
