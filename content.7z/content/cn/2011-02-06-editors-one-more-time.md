---
title: 说编辑编辑到
date: '2011-02-06'
slug: editors-one-more-time
---

昨天[刚说了写关于论文和编辑的事情](/cn/2011/02/papers-and-editors/)，今天一开电脑，发现某刊物让我帮忙审论文；小喽罗审大老前辈的文章，有点儿意思。
