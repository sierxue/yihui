---
title: I Hate Urgent Problems
date: '2007-06-11T20:38:04+08:00'
slug: i-hate-urgent-problems
---

I don't understand why these people never remember to ask for help earlier until the deadline is quite near. In the past, I've met a great many such people. Frankly speaking, I have absolutely NO sympathy for their difficulties. For instance, yesterday a guy sent a short message to me asking for help with his structural equation modeling, and told me the deadline was tomorrow. I couldn't help being angry. Perhaps they think statistics is just too easy and I have a lot of leisure time.

Just now, I remembered some "generous" words between friends, which often appear in TV plays: "Your XXX is my XXX, and my XXX is your XXX." (e.g. Your business is my business, and my business is your business. However, they're always modified as "My business is your business, and your business is still your business." Poor guy...)  

