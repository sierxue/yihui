---
title: 突闻网易CEO辞世
date: '2005-09-21'
slug: netease-ceo
---

咋搞的？难道最近人都比较短命？
