---
title: 强国梦
date: '2007-09-04'
slug: dream-of-strong-country
---

[这篇文章](http://finance.sina.com.cn/g/20070810/00353868755.shtml)不错，不过貌似找不到电子书。
